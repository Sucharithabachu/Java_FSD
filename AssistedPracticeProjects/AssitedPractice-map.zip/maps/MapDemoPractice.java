package maps;
import java.util.*;

public class MapDemoPractice {
	public static void main(String[] args) {
	     HashMap<Integer,String> hm=new HashMap<Integer,String>();      
	      hm.put(1,"Ramu");    
	      hm.put(2,"Somu");    
	      hm.put(3,"Shyamu");   
	      System.out.println("\nThe elements of Hashmap are ");  
	      for(Map.Entry m:hm.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();    
	      ht.put(4,"Emp4");  
	      ht.put(5,"Emp5");  
	      ht.put(6,"Emp6");  
	      ht.put(7,"Emp7");  
                   System.out.println("\nThe elements of HashTable are ");  
	      for(Map.Entry n:ht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      } 
	      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
	      map.put(8,"Emp8");    
	      map.put(9,"Emp9");    
	      map.put(10,"Emp10");       
	     System.out.println("\nThe elements of TreeMap are ");  
	      for(Map.Entry l:map.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      
	   }  
}