package AccessModifiers;

public class Accessmodifier {
	public void methodPublic() {
		System.out.println("You can see public value");
	}
	private void methodPrivate() {
		System.out.println("You can see private value");
	}
	protected void methodProtected() {
		System.out.println("You can see protected value");
	}
	void methodDefault() {
		System.out.println("You can see the default value");
	}
	public static void main(String[] args) {
		Accessmodifier obj=new Accessmodifier();
		
		obj.methodPublic();
		obj.methodPrivate();
		obj.methodProtected();
		obj.methodDefault();
		
	}
}
