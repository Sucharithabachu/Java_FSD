package AccessModifiers;

public class Ascessmoddiffcls {
	public static void main(String[] args) {
		Accessmodifier obj=new Accessmodifier();
		
		obj.methodPublic();
		//obj.methodPrivate();
		//Private cannot be accessible in same package but different class
		//Private can only accessible within same package and same class
		obj.methodProtected();
		obj.methodDefault();
		
	}

}
