package InnerClasses;

class Outer {
	 
    class Inner {
 
        public void show()
        {
 
            
            System.out.println("In nested class");
        }
    }
}
 
public class InnerClassDemo3 {
 
    public static void main(String[] args)
    {
 
        Outer.Inner in = new Outer().new Inner();
        in.show();
    }
}