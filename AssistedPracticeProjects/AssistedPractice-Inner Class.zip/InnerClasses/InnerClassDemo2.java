package InnerClasses;

class Outer1 {
	 
    void outerMethod()
    {
 
        System.out.println("inside outerMethod");
 
        class Inner1 {
 
            void innerMethod()
            {
 
                System.out.println("inside innerMethod");
            }
        }
 
        Inner1 y = new Inner1();
        y.innerMethod();
    }
}
 
public class InnerClassDemo2 {
    public static void main(String[] args) {
        Outer1 x = new Outer1();
        x.outerMethod();
    }
}