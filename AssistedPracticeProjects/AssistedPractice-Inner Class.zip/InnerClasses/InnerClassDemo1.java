package InnerClasses;
interface Hello {
	
    void show();
}
public class InnerClassDemo1 {
    static Hello h = new Hello() {
        
    public void show()
    {
        
        System.out.println("Anonymous class");
    }
  
}; 
    public static void main(String[] args)
    {
        h.show();
    }
}