package InnerClasses;
import java.util.*;
class Outer2 {
	 

    private static void outerMethod()
    {
 
        
        System.out.println("inside outerMethod");
    }
 
    static class Inner1 {
 
        public static void display()
        {
 
            
            System.out.println("inside inner class Method");
 
            
            outerMethod();
        }
    }
}
 

class InnerClassDemo4 {
 
    
    public static void main(String args[])
    {
 
        Outer2.Inner1 obj = new Outer2.Inner1();
 
        obj.display();

    }
}