package Constructorpackage;

public class EmployeeDetails {
	
	int empId;
	String empName;
	String department;
	double salary;
	
	//default constructor
	public EmployeeDetails() {
		empId=7777;
		empName="Suchi";
		department="Trainer";
		salary=70000;
	}
	
	//parameterized constructor
	public EmployeeDetails(int empId,String empName,String department,double salary) {
		this.empId=empId;
		this.empName=empName;
		this.department=department;
		this.salary=salary;
	}
	
	public void display() {
		System.out.println("Id: "+empId);
		System.out.println("Name: "+empName);
		System.out.println("Department: "+department);
		System.out.println("Salary: "+salary);
		System.out.println();
		
	}
	
	public static void main(String[] args) {
		
		EmployeeDetails e= new EmployeeDetails();
		EmployeeDetails e1= new EmployeeDetails(4012, "Sucharitha Bachu", "Full Stack", 450000); 

		//calling default constructor
		e.display();
		//Parameterized constructor
		e1.display();
		
		 
	
	}

	
}